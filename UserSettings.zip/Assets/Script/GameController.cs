using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gamecontroller : MonoBehaviour
{ public float Timer = 1.0f;
    public GameObject RemoverObject;
    public int CharacterHit = 30;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    { Timer -= Time.deltaTime;

        if (Timer <= 0)
        { Timer = 1;

            GameObject Temp = Instantiate(RemoverObject);
        }
        if (Input.GetMouseButton(0))
        {
            RaycastHit hit;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            if (Physics.Raycast(ray, out hit))
            {
                if (hit.collider !=null)
                {hit.collider.gameObject.GetComponent<Remover>().CharacterHit(30) };
            }
        }
    }
}
