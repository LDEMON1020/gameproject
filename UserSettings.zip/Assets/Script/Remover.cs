using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Remover : MonoBehaviour
{
    public int Health = 100;
    public float Timer = 1.0f;
    public int AttackPoint = 50;
    // �Q\�� �������� ������Ʈ �Ǳ� �� �� �� �����Ѵ�.
    void Start()
    {
        
        Health = 100;
        
    }

    //���� ���� ���� �� ������ ���� ȣ���
    void Update()
    {
        Timer -= Time.deltaTime;
        if (Timer <= 0)
        {
            Timer = 1;
            Health += 10;
        }
        {
    
            if (Input.GetKeyDown(KeyCode.Space))
            { Health -= AttackPoint; }
          
           if (Health <= 0)
            { Destroy(gameObject); }
        }
          void CharacterHit(int Damage)
        { Health -= Damage; }


        if (Input.GetKeyDown(KeyCode.Space))
        { Health -= AttackPoint; }
        if (Health <= 0)
        {
            Destroy(gameObject);
        }
        void CharacterHealthUp()
        {

            Timer -= Time.deltaTime;
            if (Timer <=0)
            {
                Timer = 1;
                Health += 10;
            }
        }
    }void CheckDeath()

}
